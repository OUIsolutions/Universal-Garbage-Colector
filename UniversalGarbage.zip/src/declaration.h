
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>



#include "macros.h"
#include "garbage_element/garbage_element.h"
#include "garbage/garbage.h"
