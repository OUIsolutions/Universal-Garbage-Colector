

#ifndef UNIVERSAL_GARBAGE_H
#include "declaration.h"
#include "definition.h"

#define UNIVERSAL_GARBAGE_H
#endif