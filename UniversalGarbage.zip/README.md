# Universal-Garbage-Colector
Universal-Garbage is an tiny C lib for reducing memory leak problems in C
its designed with the idea of releasing all the memory of each scopes once 

# Single File installation
Like any other OUI lib, its designed to be as much easy and as much portable as possible,
so you just need to download and include the **UniversalGarbage.h** header into your code

## Full Folder
If you want to use with full folder, to make modifications into the source code, you can donwload
the entire **src** project, and include with **src/one.h**



