# Universal-Garbage-Colector
An Small lib for an universal garbage colector in C
